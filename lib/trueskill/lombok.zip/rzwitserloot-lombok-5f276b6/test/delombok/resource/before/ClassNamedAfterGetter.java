class GetFoo {
	@lombok.Getter private int foo;
}
