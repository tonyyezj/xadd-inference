//ignore
class SetterWithDollar1 {
	@lombok.Setter int $i;
}

class SetterWithDollar2 {
	@lombok.Setter int $i;
	@lombok.Setter int i;
}
