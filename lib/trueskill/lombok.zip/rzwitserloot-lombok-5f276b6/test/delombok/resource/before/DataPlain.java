import lombok.Data;
@lombok.Data class Data1 {
	final int x;
	String name;
}
@Data class Data2 {
	final int x;
	String name;
}