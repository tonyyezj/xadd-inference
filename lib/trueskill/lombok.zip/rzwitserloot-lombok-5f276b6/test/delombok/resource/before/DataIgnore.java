@lombok.Data class DataIgnore {
	final int x;
	String $name;
}
