//ignore
class GetterWithDollar1 {
	@lombok.Getter int $i;
}

class GetterWithDollar2 {
	@lombok.Getter int $i;
	@lombok.Getter int i;
}
