import lombok.ToString;
@lombok.ToString class ToString1 {
	final int x;
	String name;
}
@ToString class ToString2 {
	final int x;
	String name;
}