import lombok.Setter;
class SetterPlain {
	@lombok.Setter int i;
	@Setter int foo;
}