import lombok.Getter;
class GetterPlain {
	@lombok.Getter int i;
	@Getter int foo;
}