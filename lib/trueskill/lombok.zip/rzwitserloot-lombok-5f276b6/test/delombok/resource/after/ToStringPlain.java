class ToString1 {
	final int x;
	String name;
	@java.lang.Override
	public java.lang.String toString() {
		return "ToString1(x=" + x + ", name=" + name + ")";
	}
}
class ToString2 {
	final int x;
	String name;
	@java.lang.Override
	public java.lang.String toString() {
		return "ToString2(x=" + x + ", name=" + name + ")";
	}
}