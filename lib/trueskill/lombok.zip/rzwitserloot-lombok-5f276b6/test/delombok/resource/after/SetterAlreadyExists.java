class Setter1 {
	boolean foo;
	void setFoo(boolean foo) {
	}
}
class Setter2 {
	boolean foo;
	void setFoo(String foo) {
	}
}
class Setter3 {
	String foo;
	void setFoo(boolean foo) {
	}
}
class Setter4 {
	String foo;
	void setFoo(String foo) {
	}
}
class Setter5 {
	String foo;
	void setFoo() {
	}
}
class Setter6 {
	String foo;
	void setFoo(String foo, int x) {
	}
}
class Setter7 {
	String foo;
	static void setFoo() {
	}
}
