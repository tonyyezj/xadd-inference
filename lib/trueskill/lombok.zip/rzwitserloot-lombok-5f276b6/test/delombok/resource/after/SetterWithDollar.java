class SetterWithDollar1 {
	int $i;
	
	public void setI(final int i) {
		this.$i = i;
	}
}
class SetterWithDollar2 {
	int $i;
	int i;
	
	public void setI(final int i) {
		this.i = i;
	}
}