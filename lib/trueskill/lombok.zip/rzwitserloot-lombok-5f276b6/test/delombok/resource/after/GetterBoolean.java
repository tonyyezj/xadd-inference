class Getter {
	boolean foo;
	boolean isBar;
	boolean hasBaz;
	public boolean isFoo() {
		return foo;
	}
	public boolean isBar() {
		return isBar;
	}
	public boolean hasBaz() {
		return hasBaz;
	}
}
class MoreGetter {
	boolean foo;
	boolean hasFoo() {
		return true;
	}
}