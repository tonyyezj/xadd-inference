class GetterWithDollar1 {
	int $i;
	
	public int getI() {
		return $i;
	}
}
class GetterWithDollar2 {
	int $i;
	int i;
	
	public int getI() {
		return i;
	}
}