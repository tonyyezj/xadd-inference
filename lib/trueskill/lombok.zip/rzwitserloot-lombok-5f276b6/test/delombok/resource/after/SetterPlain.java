class SetterPlain {
	int i;
	int foo;
	public void setI(final int i) {
		this.i = i;
	}
	public void setFoo(final int foo) {
		this.foo = foo;
	}
}