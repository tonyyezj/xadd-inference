class GetFoo {
	private int foo;
	public int getFoo() {
		return foo;
	}
}
