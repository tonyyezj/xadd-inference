/* cmt *//* cmt2 */ /* cmt3 */ /*bla */
public class CommentsInterspersed {
	/** javadoc for field */
	private int x;
	/* bla2 */ private String test = "foo"; //$NON-NLS-1$
	/** Javadoc on method */
	public native void gwtTest(); /*-{
		javascript;
	}-*/
	public String getTest() {
		return test;
	}
} //haha!
//hahaha!
//hahahaha!
