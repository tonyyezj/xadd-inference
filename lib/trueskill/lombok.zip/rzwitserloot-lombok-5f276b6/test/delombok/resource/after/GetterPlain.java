class GetterPlain {
	int i;
	int foo;
	public int getI() {
		return i;
	}
	public int getFoo() {
		return foo;
	}
}