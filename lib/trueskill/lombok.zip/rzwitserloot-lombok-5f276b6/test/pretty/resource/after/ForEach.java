import java.util.Arrays;
public class ForEach {
	{
		for (int i : Arrays.asList(1, 2, 3)) {
			System.out.println(i);
			// Do something
		}
	}
}
