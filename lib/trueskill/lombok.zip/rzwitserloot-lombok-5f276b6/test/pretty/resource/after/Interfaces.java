@SuppressWarnings("all")
interface Interfaces {
	int x = 10;
	void y();
	public static final int a = 20;
	public abstract void b();
}
